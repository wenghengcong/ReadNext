//
//  WMMutableAttributedImage.h
//  WMCoreText
//
//  Created by yan on 2018/11/19.
//  Copyright © 2018年 sankuai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#import <WMMutableAttributedItem.h>

NS_ASSUME_NONNULL_BEGIN

@interface WMPoiListAttributedImage : WMMutableAttributedItem

@end

NS_ASSUME_NONNULL_END

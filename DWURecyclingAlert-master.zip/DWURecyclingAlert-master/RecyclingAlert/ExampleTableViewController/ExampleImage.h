//
//  ExampleImage.h
//  RecyclingAlert
//
//  Created by Di Wu on 6/13/15.
//  Copyright © 2015 Di Wu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExampleImage : NSObject

+ (UIImage *)recycledImage;

+ (UIImage *)nonRecycledImage;

@end

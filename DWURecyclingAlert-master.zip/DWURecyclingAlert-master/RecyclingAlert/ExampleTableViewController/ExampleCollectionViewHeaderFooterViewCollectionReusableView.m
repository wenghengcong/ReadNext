//
//  ExampleCollectionViewHeaderFooterViewCollectionReusableView.m
//  RecyclingAlert
//
//  Created by Di Wu on 6/30/15.
//  Copyright (c) 2015 Di Wu. All rights reserved.
//

#import "ExampleCollectionViewHeaderFooterViewCollectionReusableView.h"

@implementation ExampleCollectionViewHeaderFooterViewCollectionReusableView

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.backgroundColor = [UIColor purpleColor];
    }
    return self;
}

@end

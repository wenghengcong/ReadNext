//
//  ExampleSimulatedWorkLoad.h
//  RecyclingAlert
//
//  Created by Di Wu on 6/20/15.
//  Copyright (c) 2015 Di Wu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ExampleSimulatedWorkLoad : NSObject

+ (void)doSimulatedWorkLoad;

@end

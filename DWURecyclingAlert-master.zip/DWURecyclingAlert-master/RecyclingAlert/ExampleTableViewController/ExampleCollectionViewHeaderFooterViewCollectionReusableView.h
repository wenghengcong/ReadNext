//
//  ExampleCollectionViewHeaderFooterViewCollectionReusableView.h
//  RecyclingAlert
//
//  Created by Di Wu on 6/30/15.
//  Copyright (c) 2015 Di Wu. All rights reserved.
//

#import <UIKit/UIKit.h>

static NSString *ExampleCollectionViewHeaderFooterViewCollectionReusableViewHeaderIdentifier = @"ExampleCollectionViewHeaderFooterViewCollectionReusableViewHeaderIdentifier";

static NSString *ExampleCollectionViewHeaderFooterViewCollectionReusableViewFooterIdentifier = @"ExampleCollectionViewHeaderFooterViewCollectionReusableViewFooterIdentifier";

@interface ExampleCollectionViewHeaderFooterViewCollectionReusableView : UICollectionReusableView

@end
